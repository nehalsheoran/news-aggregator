import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

export function MainNav() {
  return (
    <div className="flex items-center space-x-4 lg:space-x-6">
      <Link href="/" className="flex items-center space-x-2">
        <span className="font-bold text-xl">News Feed</span>
      </Link>
      <nav className="flex items-center space-x-4 lg:space-x-6">
        <Link href="/feed" className="text-sm font-medium transition-colors hover:text-primary">
          Feed
        </Link>
        <Link href="/topics" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
          Topics
        </Link>
        <Link
          href="/bookmarks"
          className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          Bookmarks
        </Link>
      </nav>
      <div className="hidden md:flex ml-auto mr-4">
        <Button variant="ghost" size="icon">
          <Link href="/search">
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Link>
        </Button>
      </div>
    </div>
  )
}
