import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

export function SourceFilter() {
  const sources = [
    { id: "nyt", label: "New York Times" },
    { id: "cnn", label: "CNN" },
    { id: "bbc", label: "BBC" },
    { id: "reuters", label: "Reuters" },
    { id: "ap", label: "Associated Press" },
    { id: "wapo", label: "Washington Post" },
  ]

  return (
    <div className="space-y-2">
      {sources.map((source) => (
        <div key={source.id} className="flex items-center space-x-2">
          <Checkbox id={source.id} />
          <Label htmlFor={source.id} className="text-sm font-normal">
            {source.label}
          </Label>
        </div>
      ))}
    </div>
  )
}
