import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bookmark } from "lucide-react"
import Link from "next/link"

interface NewsCardProps {
  id: string
  title: string
  summary: string
  source: string
  time: string
  image: string
  topics: string[]
}

export function NewsCard({ id, title, summary, source, time, image, topics }: NewsCardProps) {
  return (
    <Card className="overflow-hidden h-full flex flex-col">
      <Link href={`/article/${id}`} className="block">
        <div className="aspect-video w-full overflow-hidden">
          <img
            src={image || "/placeholder.svg"}
            alt={title}
            className="object-cover w-full h-full transition-transform hover:scale-105"
          />
        </div>
      </Link>
      <CardContent className="p-4 flex-1 flex flex-col">
        <div className="flex items-center justify-between gap-2 text-sm text-muted-foreground mb-2">
          <div className="flex items-center gap-2">
            <span>{source}</span>
            <span>•</span>
            <span>{time}</span>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Bookmark className="h-4 w-4" />
            <span className="sr-only">Bookmark</span>
          </Button>
        </div>
        <Link href={`/article/${id}`} className="group">
          <h3 className="font-semibold line-clamp-2 mb-2 group-hover:text-primary transition-colors">{title}</h3>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{summary}</p>
        <div className="mt-auto flex flex-wrap gap-1">
          {topics.map((topic) => (
            <Badge key={topic} variant="secondary" className="text-xs">
              {topic}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
