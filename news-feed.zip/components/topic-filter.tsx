import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

export function TopicFilter() {
  const topics = [
    { id: "technology", label: "Technology" },
    { id: "business", label: "Business" },
    { id: "politics", label: "Politics" },
    { id: "health", label: "Health" },
    { id: "science", label: "Science" },
    { id: "sports", label: "Sports" },
    { id: "entertainment", label: "Entertainment" },
    { id: "world", label: "World" },
  ]

  return (
    <div className="space-y-2">
      {topics.map((topic) => (
        <div key={topic.id} className="flex items-center space-x-2">
          <Checkbox id={topic.id} />
          <Label htmlFor={topic.id} className="text-sm font-normal">
            {topic.label}
          </Label>
        </div>
      ))}
    </div>
  )
}
