"use server"

import { revalidatePath } from "next/cache"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import type {
  Article,
  ArticleResponse,
  Bookmark,
  BookmarkResponse,
  UserPreferences,
  PreferenceResponse,
  NewsFilters,
} from "./types"

// Fetch news articles
export async function fetchNews(filters: NewsFilters = {}): Promise<ArticleResponse> {
  const queryParams = new URLSearchParams()

  if (filters.topic) queryParams.set("topic", filters.topic)
  if (filters.source) queryParams.set("source", filters.source)
  if (filters.query) queryParams.set("query", filters.query)
  if (filters.sort) queryParams.set("sort", filters.sort)
  if (filters.page) queryParams.set("page", filters.page.toString())
  if (filters.limit) queryParams.set("limit", filters.limit.toString())

  const response = await fetch(`/api/news?${queryParams.toString()}`)

  if (!response.ok) {
    throw new Error("Failed to fetch news")
  }

  return response.json()
}

// Fetch article by ID
export async function fetchArticleById(id: string): Promise<Article> {
  const response = await fetch(`/api/news/${id}`)

  if (!response.ok) {
    throw new Error("Failed to fetch article")
  }

  return response.json()
}

// Bookmark an article
export async function bookmarkArticle(articleId: string, folder = "Default"): Promise<Bookmark> {
  const response = await fetch("/api/bookmarks", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      articleId,
      folder,
    }),
  })

  if (!response.ok) {
    throw new Error("Failed to bookmark article")
  }

  revalidatePath("/bookmarks")
  return response.json()
}

// Remove a bookmark
export async function removeBookmark(bookmarkId: string): Promise<void> {
  const response = await fetch(`/api/bookmarks?id=${bookmarkId}`, {
    method: "DELETE",
  })

  if (!response.ok) {
    throw new Error("Failed to remove bookmark")
  }

  revalidatePath("/bookmarks")
}

// Fetch user bookmarks
export async function fetchBookmarks(folder?: string, isRead?: boolean): Promise<BookmarkResponse> {
  const queryParams = new URLSearchParams()

  if (folder) queryParams.set("folder", folder)
  if (isRead !== undefined) queryParams.set("isRead", isRead.toString())

  const response = await fetch(`/api/bookmarks?${queryParams.toString()}`)

  if (!response.ok) {
    throw new Error("Failed to fetch bookmarks")
  }

  return response.json()
}

// Update user preferences
export async function updatePreferences(preferences: Partial<UserPreferences>): Promise<PreferenceResponse> {
  const response = await fetch("/api/preferences", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(preferences),
  })

  if (!response.ok) {
    throw new Error("Failed to update preferences")
  }

  revalidatePath("/settings")
  return response.json()
}

// Fetch user preferences
export async function fetchPreferences(): Promise<PreferenceResponse> {
  const response = await fetch("/api/preferences")

  if (!response.ok) {
    throw new Error("Failed to fetch preferences")
  }

  return response.json()
}

// User authentication actions
export async function signIn(email: string, password: string): Promise<void> {
  // In a real application, this would validate credentials against a database
  if (email !== "user@example.com" || password !== "password") {
    throw new Error("Invalid credentials")
  }

  // Set a cookie to simulate authentication
  cookies().set("auth", "authenticated", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 1 week
    path: "/",
  })

  redirect("/feed")
}

export async function signUp(email: string, password: string, name: string): Promise<void> {
  // In a real application, this would create a new user in the database

  // Set a cookie to simulate authentication
  cookies().set("auth", "authenticated", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 1 week
    path: "/",
  })

  redirect("/onboarding")
}

export async function signOut(): Promise<void> {
  cookies().delete("auth")
  redirect("/")
}
