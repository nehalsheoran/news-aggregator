// Article Types
export interface Article {
  id: string
  title: string
  summary: string
  content: string
  source: string
  author: string
  publishedAt: string
  updatedAt: string
  url: string
  imageUrl: string
  topics: string[]
  readTime: number
  popularity: number
}

export interface ArticleResponse {
  data: Article[]
  meta: {
    total: number
    page: number
    limit: number
    totalPages: number
  }
}

// User Types
export interface User {
  id: string
  name: string
  email: string
  image?: string
  bio?: string
  createdAt: string
}

// Bookmark Types
export interface Bookmark {
  id: string
  userId: string
  articleId: string
  createdAt: string
  folder: string
  isRead: boolean
}

export interface BookmarkResponse {
  data: Bookmark[]
}

// Preference Types
export interface UserPreferences {
  topics: string[]
  sources: string[]
  layout: "grid" | "list" | "magazine"
  theme: "light" | "dark" | "system"
  showTrending: boolean
  showRecommended: boolean
  showLocal: boolean
  articleDensity: "compact" | "medium" | "comfortable"
  fontSize: "small" | "medium" | "large"
}

export interface PreferenceResponse {
  data: UserPreferences
}

// Filter Types
export interface NewsFilters {
  topic?: string
  source?: string
  query?: string
  sort?: "latest" | "trending"
  page?: number
  limit?: number
}

// Notification Types
export interface NotificationSettings {
  emailDigest: boolean
  emailBreakingNews: boolean
  emailTopicUpdates: boolean
  pushBreakingNews: boolean
  pushRecommendations: boolean
  digestFrequency: "daily" | "weekly" | "monthly"
  digestTime: "morning" | "afternoon" | "evening"
}
