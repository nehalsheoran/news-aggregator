import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Bookmark, Share2, ThumbsUp, MessageSquare, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function ArticlePage({ params }: { params: { id: string } }) {
  return (
    <div className="container py-6">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-3/4 space-y-6">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" asChild>
              <Link href="/feed">
                <ArrowLeft className="h-4 w-4" />
                <span className="sr-only">Back</span>
              </Link>
            </Button>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>Source Name</span>
              <span>•</span>
              <span>2 hours ago</span>
            </div>
          </div>

          <article className="space-y-6">
            <h1 className="text-3xl font-bold">{`Article Title for ${params.id}`}</h1>

            <div className="flex flex-wrap gap-2">
              <Badge variant="secondary">Technology</Badge>
              <Badge variant="secondary">Business</Badge>
            </div>

            <div className="aspect-video w-full overflow-hidden rounded-lg">
              <img
                src="/placeholder.svg?height=400&width=800"
                alt="Article featured image"
                className="object-cover w-full h-full"
              />
            </div>

            <div className="prose prose-sm sm:prose lg:prose-lg max-w-none">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                ex ea commodo consequat.
              </p>
              <p>
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                laborum.
              </p>
              <h2>Subheading for the Article</h2>
              <p>
                Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam
                rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt
                explicabo.
              </p>
              <p>
                Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni
                dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia
                dolor sit amet, consectetur, adipisci velit.
              </p>
              <blockquote>
                This is a quote from someone important related to this article. It adds credibility and a different
                perspective to the content.
              </blockquote>
              <p>
                At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum
                deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non
                provident.
              </p>
            </div>

            <div className="flex items-center justify-between pt-4 border-t">
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <ThumbsUp className="h-4 w-4" />
                  Like
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <MessageSquare className="h-4 w-4" />
                  Comment
                </Button>
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <Share2 className="h-4 w-4" />
                  Share
                </Button>
              </div>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Bookmark className="h-4 w-4" />
                Bookmark
              </Button>
            </div>
          </article>
        </div>

        <div className="w-full md:w-1/4 space-y-6">
          <div className="sticky top-20">
            <h2 className="text-lg font-semibold mb-4">Related Articles</h2>
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <Link href={`/article/related-${i}`} className="block">
                    <div className="aspect-video w-full overflow-hidden">
                      <img
                        src={`/placeholder.svg?height=100&width=200&text=Related+${i}`}
                        alt={`Related article ${i}`}
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <CardContent className="p-3">
                      <h3 className="font-medium text-sm line-clamp-2">Related Article Headline {i}</h3>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <span>Source</span>
                        <span>•</span>
                        <span>3 hours ago</span>
                      </div>
                    </CardContent>
                  </Link>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
