import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, TrendingUp, Clock } from "lucide-react"
import { TopicFilter } from "@/components/topic-filter"
import { SourceFilter } from "@/components/source-filter"
import { NewsCard } from "@/components/news-card"

export default function FeedPage() {
  return (
    <div className="container py-6">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar with filters */}
        <div className="w-full md:w-64 space-y-6">
          <div className="sticky top-20">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Filters</h2>
                <Button variant="ghost" size="sm">
                  Reset
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Topics</h3>
                <TopicFilter />
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Sources</h3>
                <SourceFilter />
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Date Range</h3>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm">
                    Today
                  </Button>
                  <Button variant="outline" size="sm">
                    This Week
                  </Button>
                  <Button variant="outline" size="sm">
                    This Month
                  </Button>
                  <Button variant="outline" size="sm">
                    Custom
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-2xl font-bold">Your News Feed</h1>
            <div className="flex items-center w-full sm:w-auto">
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search articles..." className="w-full sm:w-[300px] pl-8" />
              </div>
              <Button variant="ghost" size="icon" className="ml-2">
                <Filter className="h-4 w-4" />
                <span className="sr-only">Filter</span>
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="flex items-center gap-1">
              Technology
              <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1">
                ×
              </Button>
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              CNN
              <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1">
                ×
              </Button>
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              Last 24 hours
              <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1">
                ×
              </Button>
            </Badge>
          </div>

          <Tabs defaultValue="for-you" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="for-you">For You</TabsTrigger>
              <TabsTrigger value="trending" className="flex items-center gap-1">
                <TrendingUp className="h-4 w-4" />
                Trending
              </TabsTrigger>
              <TabsTrigger value="latest" className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                Latest
              </TabsTrigger>
            </TabsList>

            <TabsContent value="for-you" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                  <NewsCard
                    key={i}
                    id={`article-${i}`}
                    title={`Personalized Article Headline ${i}`}
                    summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                    source="Source Name"
                    time="2 hours ago"
                    image={`/placeholder.svg?height=200&width=300&text=News+${i}`}
                    topics={["Technology", "Business"]}
                  />
                ))}
              </div>
              <div className="mt-8 flex justify-center">
                <Button>Load More</Button>
              </div>
            </TabsContent>

            <TabsContent value="trending" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <NewsCard
                    key={i}
                    id={`trending-${i}`}
                    title={`Trending Article Headline ${i}`}
                    summary="This is a brief summary of the trending news article that gives the reader an idea of what the article is about."
                    source="Trending Source"
                    time="5 hours ago"
                    image={`/placeholder.svg?height=200&width=300&text=Trending+${i}`}
                    topics={["Politics", "World"]}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="latest" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <NewsCard
                    key={i}
                    id={`latest-${i}`}
                    title={`Latest Article Headline ${i}`}
                    summary="This is a brief summary of the latest news article that gives the reader an idea of what the article is about."
                    source="Latest Source"
                    time="30 minutes ago"
                    image={`/placeholder.svg?height=200&width=300&text=Latest+${i}`}
                    topics={["Health", "Science"]}
                  />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
