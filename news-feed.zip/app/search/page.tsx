import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Search, Newspaper } from "lucide-react"
import { NewsCard } from "@/components/news-card"
import { TopicFilter } from "@/components/topic-filter"
import { SourceFilter } from "@/components/source-filter"

export default function SearchPage() {
  return (
    <div className="container py-6">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar with filters */}
        <div className="w-full md:w-64 space-y-6">
          <div className="sticky top-20">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold">Filters</h2>
                <Button variant="ghost" size="sm">
                  Reset
                </Button>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Topics</h3>
                <TopicFilter />
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Sources</h3>
                <SourceFilter />
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Date Range</h3>
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm">
                    Today
                  </Button>
                  <Button variant="outline" size="sm">
                    This Week
                  </Button>
                  <Button variant="outline" size="sm">
                    This Month
                  </Button>
                  <Button variant="outline" size="sm">
                    Custom
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 space-y-6">
          <div className="flex flex-col gap-4">
            <h1 className="text-2xl font-bold">Search</h1>
            <div className="flex items-center w-full">
              <div className="relative w-full">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input type="search" placeholder="Search for news articles..." className="w-full pl-8" />
              </div>
              <Button className="ml-2">Search</Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="flex items-center gap-1">
              Technology
              <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1">
                ×
              </Button>
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              Last 24 hours
              <Button variant="ghost" size="sm" className="h-4 w-4 p-0 ml-1">
                ×
              </Button>
            </Badge>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="articles">Articles</TabsTrigger>
              <TabsTrigger value="sources">Sources</TabsTrigger>
              <TabsTrigger value="topics">Topics</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                  <NewsCard
                    key={i}
                    id={`search-${i}`}
                    title={`Search Result Article ${i}`}
                    summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                    source="Source Name"
                    time="2 hours ago"
                    image={`/placeholder.svg?height=200&width=300&text=Search+${i}`}
                    topics={["Technology", "Business"]}
                  />
                ))}
              </div>
              <div className="mt-8 flex justify-center">
                <Button>Load More</Button>
              </div>
            </TabsContent>

            <TabsContent value="articles" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <NewsCard
                    key={i}
                    id={`article-search-${i}`}
                    title={`Article Search Result ${i}`}
                    summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                    source="Source Name"
                    time="3 hours ago"
                    image={`/placeholder.svg?height=200&width=300&text=Article+${i}`}
                    topics={["Politics", "World"]}
                  />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="sources" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i} className="overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                          <Newspaper className="h-6 w-6" />
                        </div>
                        <div>
                          <h3 className="font-semibold">Source Name {i}</h3>
                          <p className="text-sm text-muted-foreground">123 articles</p>
                        </div>
                      </div>
                      <Button className="w-full mt-4" variant="outline">
                        View Source
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="topics" className="mt-6">
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {["Technology", "Business", "Politics", "Health", "Science", "Sports"].map((topic, i) => (
                  <Card key={topic} className="overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="font-bold text-primary">{topic.charAt(0)}</span>
                        </div>
                        <div>
                          <h3 className="font-semibold">{topic}</h3>
                          <p className="text-sm text-muted-foreground">{(i + 1) * 45} articles</p>
                        </div>
                      </div>
                      <Button className="w-full mt-4" variant="outline">
                        View Topic
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
