import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, Clock, Newspaper } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-background to-muted">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  Your Personalized News Experience
                </h1>
                <p className="max-w-[600px] text-muted-foreground md:text-xl">
                  Discover, filter, and bookmark news from multiple sources, all in one place.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/feed">
                  <Button size="lg">Get Started</Button>
                </Link>
                <Link href="/topics">
                  <Button size="lg" variant="outline">
                    Explore Topics
                  </Button>
                </Link>
              </div>
            </div>
            <div className="mx-auto lg:ml-auto">
              <div className="aspect-video overflow-hidden rounded-xl">
                <img
                  alt="News Feed Dashboard"
                  className="object-cover w-full"
                  height="310"
                  src="/placeholder.svg?height=310&width=550"
                  width="550"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-12 md:py-24 lg:py-32">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Features</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Everything you need to stay informed and up-to-date with the news that matters to you.
              </p>
            </div>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-3 lg:gap-12 mt-8">
            <Card>
              <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <Newspaper className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Aggregated Headlines</h3>
                <p className="text-muted-foreground">
                  News from multiple sources, all in one place, categorized and easy to browse.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Personalized Recommendations</h3>
                <p className="text-muted-foreground">
                  Get news tailored to your interests based on your reading habits and preferences.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 flex flex-col items-center text-center space-y-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Daily Digest</h3>
                <p className="text-muted-foreground">
                  Receive a daily email with the top news stories based on your preferences.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Sample News Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Today's Headlines</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                A sample of what you'll find on News Feed.
              </p>
            </div>
          </div>
          <div className="mx-auto max-w-5xl mt-8">
            <Tabs defaultValue="trending" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="latest">Latest</TabsTrigger>
                <TabsTrigger value="tech">Technology</TabsTrigger>
              </TabsList>
              <TabsContent value="trending" className="mt-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <Card key={i} className="overflow-hidden">
                      <div className="aspect-video w-full overflow-hidden">
                        <img
                          src={`/placeholder.svg?height=200&width=300&text=News+${i}`}
                          alt={`News ${i}`}
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <span>Source Name</span>
                          <span>•</span>
                          <span>2 hours ago</span>
                        </div>
                        <h3 className="font-semibold line-clamp-2 mb-2">
                          Sample Headline for Trending News Article {i}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          This is a brief summary of the news article that gives the reader an idea of what the article
                          is about.
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="latest" className="mt-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <Card key={i} className="overflow-hidden">
                      <div className="aspect-video w-full overflow-hidden">
                        <img
                          src={`/placeholder.svg?height=200&width=300&text=Latest+${i}`}
                          alt={`Latest ${i}`}
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <span>Source Name</span>
                          <span>•</span>
                          <span>30 minutes ago</span>
                        </div>
                        <h3 className="font-semibold line-clamp-2 mb-2">Sample Headline for Latest News Article {i}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          This is a brief summary of the news article that gives the reader an idea of what the article
                          is about.
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="tech" className="mt-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <Card key={i} className="overflow-hidden">
                      <div className="aspect-video w-full overflow-hidden">
                        <img
                          src={`/placeholder.svg?height=200&width=300&text=Tech+${i}`}
                          alt={`Tech ${i}`}
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <span>Tech Source</span>
                          <span>•</span>
                          <span>1 hour ago</span>
                        </div>
                        <h3 className="font-semibold line-clamp-2 mb-2">
                          Sample Headline for Technology News Article {i}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          This is a brief summary of the news article that gives the reader an idea of what the article
                          is about.
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>
    </div>
  )
}
