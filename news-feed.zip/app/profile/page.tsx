import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { NewsCard } from "@/components/news-card"

export default function ProfilePage() {
  return (
    <div className="container py-6">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row gap-6 items-start">
          <div className="w-full md:w-1/3 lg:w-1/4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center space-y-4">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src="/placeholder.svg?height=96&width=96" alt="@user" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <div>
                    <h2 className="text-xl font-bold">John Doe</h2>
                    <p className="text-sm text-muted-foreground">john.doe@example.com</p>
                  </div>
                  <div className="flex flex-wrap justify-center gap-2">
                    <Badge variant="secondary">Technology</Badge>
                    <Badge variant="secondary">Business</Badge>
                    <Badge variant="secondary">Science</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">Joined April 2023 • 120 articles read</p>
                  <Button className="w-full" variant="outline">
                    Edit Profile
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="w-full md:w-2/3 lg:w-3/4">
            <Tabs defaultValue="activity" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="activity">Activity</TabsTrigger>
                <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
                <TabsTrigger value="comments">Comments</TabsTrigger>
              </TabsList>

              <TabsContent value="activity" className="mt-6">
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold">Recently Read</h3>
                  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <NewsCard
                        key={i}
                        id={`activity-${i}`}
                        title={`Recently Read Article ${i}`}
                        summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                        source="Source Name"
                        time="Read 2 days ago"
                        image={`/placeholder.svg?height=200&width=300&text=Activity+${i}`}
                        topics={["Technology", "Business"]}
                      />
                    ))}
                  </div>

                  <h3 className="text-lg font-semibold mt-8">Reading History</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">This Week</h4>
                      <span className="text-sm text-muted-foreground">12 articles</span>
                    </div>
                    <div className="h-8 w-full bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary w-3/4 rounded-full"></div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold">24</div>
                        <div className="text-sm text-muted-foreground">Articles Read</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">8</div>
                        <div className="text-sm text-muted-foreground">Bookmarks</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">3</div>
                        <div className="text-sm text-muted-foreground">Comments</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">5</div>
                        <div className="text-sm text-muted-foreground">Shares</div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="bookmarks" className="mt-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <NewsCard
                      key={i}
                      id={`bookmark-${i}`}
                      title={`Bookmarked Article ${i}`}
                      summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                      source="Source Name"
                      time="Bookmarked 3 days ago"
                      image={`/placeholder.svg?height=200&width=300&text=Bookmark+${i}`}
                      topics={["Politics", "World"]}
                    />
                  ))}
                </div>
                <div className="mt-8 flex justify-center">
                  <Button variant="outline">View All Bookmarks</Button>
                </div>
              </TabsContent>

              <TabsContent value="comments" className="mt-6">
                <div className="space-y-6">
                  {[1, 2, 3].map((i) => (
                    <Card key={i}>
                      <CardContent className="p-6">
                        <div className="flex flex-col space-y-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-4">
                              <Avatar className="h-10 w-10">
                                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@user" />
                                <AvatarFallback>JD</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">John Doe</div>
                                <div className="text-sm text-muted-foreground">
                                  Commented on <span className="font-medium">Article Title {i}</span> • 2 days ago
                                </div>
                              </div>
                            </div>
                          </div>
                          <p className="text-sm">
                            This is a great article! I found the analysis of the economic implications particularly
                            insightful. Looking forward to more content like this.
                          </p>
                          <div className="flex items-center gap-4">
                            <Button variant="ghost" size="sm">
                              Reply
                            </Button>
                            <Button variant="ghost" size="sm">
                              Edit
                            </Button>
                            <Button variant="ghost" size="sm">
                              Delete
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
