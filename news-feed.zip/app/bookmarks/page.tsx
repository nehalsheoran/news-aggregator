import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search, Bookmark, FolderPlus, Trash2 } from "lucide-react"
import { NewsCard } from "@/components/news-card"

export default function BookmarksPage() {
  return (
    <div className="container py-6">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h1 className="text-2xl font-bold">Your Bookmarks</h1>
          <div className="flex items-center w-full sm:w-auto gap-2">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search bookmarks..." className="w-full sm:w-[300px] pl-8" />
            </div>
            <Button variant="outline" size="icon">
              <FolderPlus className="h-4 w-4" />
              <span className="sr-only">New folder</span>
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4 sm:w-[400px]">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="unread">Unread</TabsTrigger>
            <TabsTrigger value="read">Read</TabsTrigger>
            <TabsTrigger value="folders">Folders</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <div className="text-sm text-muted-foreground">24 bookmarks</div>
              <Button variant="ghost" size="sm" className="flex items-center gap-1">
                <Trash2 className="h-4 w-4" />
                Clear All
              </Button>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
                <NewsCard
                  key={i}
                  id={`bookmark-${i}`}
                  title={`Bookmarked Article ${i}`}
                  summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                  source="Source Name"
                  time="Bookmarked 2 days ago"
                  image={`/placeholder.svg?height=200&width=300&text=Bookmark+${i}`}
                  topics={["Technology", "Business"]}
                />
              ))}
            </div>
            <div className="mt-8 flex justify-center">
              <Button>Load More</Button>
            </div>
          </TabsContent>

          <TabsContent value="unread" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <div className="text-sm text-muted-foreground">12 unread bookmarks</div>
              <Button variant="ghost" size="sm" className="flex items-center gap-1">
                <Trash2 className="h-4 w-4" />
                Clear All
              </Button>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <NewsCard
                  key={i}
                  id={`unread-${i}`}
                  title={`Unread Article ${i}`}
                  summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                  source="Source Name"
                  time="Bookmarked yesterday"
                  image={`/placeholder.svg?height=200&width=300&text=Unread+${i}`}
                  topics={["Politics", "World"]}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="read" className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <div className="text-sm text-muted-foreground">12 read bookmarks</div>
              <Button variant="ghost" size="sm" className="flex items-center gap-1">
                <Trash2 className="h-4 w-4" />
                Clear All
              </Button>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <NewsCard
                  key={i}
                  id={`read-${i}`}
                  title={`Read Article ${i}`}
                  summary="This is a brief summary of the news article that gives the reader an idea of what the article is about."
                  source="Source Name"
                  time="Read 3 days ago"
                  image={`/placeholder.svg?height=200&width=300&text=Read+${i}`}
                  topics={["Health", "Science"]}
                />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="folders" className="mt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {["Technology", "Must Read", "Research", "Work", "Personal", "Later"].map((folder, i) => (
                <Card key={folder} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center">
                          <Bookmark className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{folder}</h3>
                          <p className="text-sm text-muted-foreground">{(i + 1) * 3} articles</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete folder</span>
                      </Button>
                    </div>
                    <Button className="w-full mt-4" variant="outline">
                      View Folder
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
