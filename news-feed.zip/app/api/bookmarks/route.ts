import { NextResponse } from "next/server"

// Mock data for demonstration purposes
const mockBookmarks = [
  {
    id: "1",
    userId: "user123",
    articleId: "1",
    createdAt: "2023-04-16T10:30:00Z",
    folder: "Technology",
    isRead: false,
  },
  {
    id: "2",
    userId: "user123",
    articleId: "2",
    createdAt: "2023-04-15T14:45:00Z",
    folder: "Must Read",
    isRead: true,
  },
  // Add more mock bookmarks as needed
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)

  // In a real application, you would get the user ID from the session
  const userId = "user123"

  // Parse query parameters
  const folder = searchParams.get("folder")
  const isRead = searchParams.get("isRead")

  // Filter bookmarks based on query parameters
  let filteredBookmarks = mockBookmarks.filter((bookmark) => bookmark.userId === userId)

  if (folder) {
    filteredBookmarks = filteredBookmarks.filter((bookmark) => bookmark.folder === folder)
  }

  if (isRead !== null) {
    const readStatus = isRead === "true"
    filteredBookmarks = filteredBookmarks.filter((bookmark) => bookmark.isRead === readStatus)
  }

  // Return response
  return NextResponse.json({
    data: filteredBookmarks,
  })
}

export async function POST(request: Request) {
  const body = await request.json()

  // In a real application, you would get the user ID from the session
  const userId = "user123"

  // Validate request body
  if (!body.articleId) {
    return NextResponse.json({ error: "Article ID is required" }, { status: 400 })
  }

  // Create new bookmark
  const newBookmark = {
    id: Date.now().toString(),
    userId,
    articleId: body.articleId,
    createdAt: new Date().toISOString(),
    folder: body.folder || "Default",
    isRead: body.isRead || false,
  }

  // In a real application, you would save this to a database
  mockBookmarks.push(newBookmark)

  // Return response
  return NextResponse.json(
    {
      data: newBookmark,
    },
    { status: 201 },
  )
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url)
  const bookmarkId = searchParams.get("id")

  // In a real application, you would get the user ID from the session
  const userId = "user123"

  // Validate request
  if (!bookmarkId) {
    return NextResponse.json({ error: "Bookmark ID is required" }, { status: 400 })
  }

  // Find bookmark index
  const bookmarkIndex = mockBookmarks.findIndex((bookmark) => bookmark.id === bookmarkId && bookmark.userId === userId)

  // Check if bookmark exists
  if (bookmarkIndex === -1) {
    return NextResponse.json({ error: "Bookmark not found" }, { status: 404 })
  }

  // Remove bookmark
  mockBookmarks.splice(bookmarkIndex, 1)

  // Return response
  return NextResponse.json({
    success: true,
  })
}
