import { NextResponse } from "next/server"

// Mock data for demonstration purposes
const mockNews = [
  {
    id: "1",
    title: "New Technology Breakthrough Promises Faster Computing",
    summary: "Researchers have developed a new quantum computing method that could revolutionize processing speeds.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    source: "Tech Daily",
    author: "Jane Smith",
    publishedAt: "2023-04-15T09:30:00Z",
    updatedAt: "2023-04-15T11:45:00Z",
    url: "https://example.com/tech-breakthrough",
    imageUrl: "/placeholder.svg?height=400&width=600&text=Tech+News",
    topics: ["Technology", "Computing", "Research"],
    readTime: 5,
    popularity: 0.89,
  },
  {
    id: "2",
    title: "Global Markets React to Economic Policy Changes",
    summary: "Stock markets worldwide show mixed reactions to the latest economic policy announcements.",
    content:
      "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    source: "Financial Times",
    author: "Robert Johnson",
    publishedAt: "2023-04-14T14:20:00Z",
    updatedAt: "2023-04-14T16:30:00Z",
    url: "https://example.com/market-reactions",
    imageUrl: "/placeholder.svg?height=400&width=600&text=Financial+News",
    topics: ["Business", "Economy", "Markets"],
    readTime: 7,
    popularity: 0.76,
  },
  // Add more mock articles as needed
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)

  // Parse query parameters
  const topic = searchParams.get("topic")
  const source = searchParams.get("source")
  const query = searchParams.get("query")
  const sort = searchParams.get("sort") || "latest"
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")

  // Filter news based on query parameters
  let filteredNews = [...mockNews]

  if (topic) {
    filteredNews = filteredNews.filter((article) => article.topics.some((t) => t.toLowerCase() === topic.toLowerCase()))
  }

  if (source) {
    filteredNews = filteredNews.filter((article) => article.source.toLowerCase() === source.toLowerCase())
  }

  if (query) {
    filteredNews = filteredNews.filter(
      (article) =>
        article.title.toLowerCase().includes(query.toLowerCase()) ||
        article.summary.toLowerCase().includes(query.toLowerCase()),
    )
  }

  // Sort news
  if (sort === "latest") {
    filteredNews.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
  } else if (sort === "trending") {
    filteredNews.sort((a, b) => b.popularity - a.popularity)
  }

  // Paginate results
  const startIndex = (page - 1) * limit
  const endIndex = page * limit
  const paginatedNews = filteredNews.slice(startIndex, endIndex)

  // Return response
  return NextResponse.json({
    data: paginatedNews,
    meta: {
      total: filteredNews.length,
      page,
      limit,
      totalPages: Math.ceil(filteredNews.length / limit),
    },
  })
}
