import { NextResponse } from "next/server"

// Mock data for demonstration purposes
const mockPreferences = {
  user123: {
    topics: ["Technology", "Business", "Science"],
    sources: ["Tech Daily", "Financial Times", "Science Weekly"],
    layout: "grid",
    theme: "system",
    showTrending: true,
    showRecommended: true,
    showLocal: true,
    articleDensity: "medium",
    fontSize: "medium",
  },
}

export async function GET(request: Request) {
  // In a real application, you would get the user ID from the session
  const userId = "user123"

  // Get user preferences
  const preferences = mockPreferences[userId] || {
    topics: [],
    sources: [],
    layout: "grid",
    theme: "system",
    showTrending: true,
    showRecommended: true,
    showLocal: true,
    articleDensity: "medium",
    fontSize: "medium",
  }

  // Return response
  return NextResponse.json({
    data: preferences,
  })
}

export async function PUT(request: Request) {
  const body = await request.json()

  // In a real application, you would get the user ID from the session
  const userId = "user123"

  // Get current preferences
  const currentPreferences = mockPreferences[userId] || {
    topics: [],
    sources: [],
    layout: "grid",
    theme: "system",
    showTrending: true,
    showRecommended: true,
    showLocal: true,
    articleDensity: "medium",
    fontSize: "medium",
  }

  // Update preferences
  const updatedPreferences = {
    ...currentPreferences,
    ...body,
  }

  // In a real application, you would save this to a database
  mockPreferences[userId] = updatedPreferences

  // Return response
  return NextResponse.json({
    data: updatedPreferences,
  })
}
