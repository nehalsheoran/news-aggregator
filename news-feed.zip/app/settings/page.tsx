import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TopicFilter } from "@/components/topic-filter"
import { SourceFilter } from "@/components/source-filter"

export default function SettingsPage() {
  return (
    <div className="container py-6">
      <div className="flex flex-col gap-6">
        <h1 className="text-2xl font-bold">Settings</h1>

        <Tabs defaultValue="preferences" className="w-full">
          <TabsList className="grid w-full grid-cols-4 sm:w-[600px]">
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
          </TabsList>

          <TabsContent value="preferences" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Content Preferences</CardTitle>
                <CardDescription>Customize your news feed based on your interests and preferences.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Topics</h3>
                  <p className="text-sm text-muted-foreground">
                    Select the topics you're interested in to personalize your feed.
                  </p>
                  <TopicFilter />
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Sources</h3>
                  <p className="text-sm text-muted-foreground">Select the news sources you prefer.</p>
                  <SourceFilter />
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Feed Settings</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="show-trending">Show trending articles</Label>
                      <Switch id="show-trending" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="show-recommended">Show recommended articles</Label>
                      <Switch id="show-recommended" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="show-local">Show local news</Label>
                      <Switch id="show-local" defaultChecked />
                    </div>
                  </div>
                </div>

                <Button>Save Preferences</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>Update your account details and manage your profile.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" placeholder="Your name" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="Your email" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea id="bio" placeholder="Tell us about yourself" />
                </div>

                <Button>Update Account</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Password</CardTitle>
                <CardDescription>Change your password to keep your account secure.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="current-password">Current Password</Label>
                  <Input id="current-password" type="password" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-password">New Password</Label>
                  <Input id="new-password" type="password" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirm New Password</Label>
                  <Input id="confirm-password" type="password" />
                </div>

                <Button>Change Password</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>Manage how and when you receive notifications.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Email Notifications</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="daily-digest">Daily news digest</Label>
                      <Switch id="daily-digest" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="breaking-news">Breaking news alerts</Label>
                      <Switch id="breaking-news" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="topic-updates">Updates on followed topics</Label>
                      <Switch id="topic-updates" defaultChecked />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Push Notifications</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="push-breaking">Breaking news</Label>
                      <Switch id="push-breaking" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="push-recommendations">Personalized recommendations</Label>
                      <Switch id="push-recommendations" defaultChecked />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Digest Settings</h3>
                  <div className="space-y-2">
                    <Label htmlFor="digest-frequency">Digest frequency</Label>
                    <Select defaultValue="daily">
                      <SelectTrigger id="digest-frequency">
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="digest-time">Preferred time</Label>
                    <Select defaultValue="morning">
                      <SelectTrigger id="digest-time">
                        <SelectValue placeholder="Select time" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">Morning (8 AM)</SelectItem>
                        <SelectItem value="afternoon">Afternoon (2 PM)</SelectItem>
                        <SelectItem value="evening">Evening (6 PM)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button>Save Notification Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="appearance" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Appearance Settings</CardTitle>
                <CardDescription>Customize how News Feed looks and feels.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Theme</h3>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="border rounded-md p-4 flex flex-col items-center gap-2 cursor-pointer hover:border-primary">
                      <div className="h-20 w-full bg-background border rounded-md"></div>
                      <span>Light</span>
                    </div>
                    <div className="border rounded-md p-4 flex flex-col items-center gap-2 cursor-pointer hover:border-primary">
                      <div className="h-20 w-full bg-black border rounded-md"></div>
                      <span>Dark</span>
                    </div>
                    <div className="border rounded-md p-4 flex flex-col items-center gap-2 cursor-pointer hover:border-primary border-primary">
                      <div className="h-20 w-full bg-gradient-to-b from-white to-black border rounded-md"></div>
                      <span>System</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Layout</h3>
                  <div className="space-y-2">
                    <Label htmlFor="article-density">Article density</Label>
                    <Select defaultValue="medium">
                      <SelectTrigger id="article-density">
                        <SelectValue placeholder="Select density" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="compact">Compact</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="comfortable">Comfortable</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="feed-layout">Feed layout</Label>
                    <Select defaultValue="grid">
                      <SelectTrigger id="feed-layout">
                        <SelectValue placeholder="Select layout" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="grid">Grid</SelectItem>
                        <SelectItem value="list">List</SelectItem>
                        <SelectItem value="magazine">Magazine</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Reading Experience</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="font-size">Font size</Label>
                      <Select defaultValue="medium">
                        <SelectTrigger id="font-size" className="w-[180px]">
                          <SelectValue placeholder="Select size" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="small">Small</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="large">Large</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="reading-mode">Reading mode</Label>
                      <Switch id="reading-mode" />
                    </div>
                  </div>
                </div>

                <Button>Save Appearance Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
